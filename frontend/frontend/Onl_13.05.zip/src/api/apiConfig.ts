const baseURL: string = "https://silvergoldreview.com/api";

export default baseURL;